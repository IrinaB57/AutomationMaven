package Currency;
import Currency.ICalculate;
public abstract class Coin implements ICalculate {
    abstract double getValue();
}
