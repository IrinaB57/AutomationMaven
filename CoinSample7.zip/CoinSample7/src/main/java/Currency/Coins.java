package Currency;

public enum Coins {
    USD,
    ILS
}
