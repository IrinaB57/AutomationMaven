package Currency;

public interface ICalculate {
    double calculate(double value);
}
